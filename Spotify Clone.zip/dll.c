#include "dll.h"
#include <stdio.h>
#include <stdlib.h>
 
list_t* create_list()  // return a newly created empty doubly linked list
{
	// DO NOT MODIFY!!!
	list_t* l = (list_t*) malloc(sizeof(list_t));
	l->head = NULL;
	l->tail = NULL;
	l->size = 0;
	return l;
}

void insert_front(list_t* list, int data)  // TODO: inserts data to the beginning of the linked list
{
	node_t *temp = (node_t*)malloc(sizeof(node_t));
	temp->data = data;
    temp->next = NULL;
    temp->prev = NULL;
	if(list->head == NULL)
	{
		list->head = temp;
		list->tail = temp;
	}
	else
	{
		temp->next = list->head;
		list->head->prev = temp;
		list->head = temp;
	}
    list->size = list->size + 1;
}

void insert_back(list_t* list, int data) // TODO: inserts data to the end of the linked list
{
    node_t *temp = (node_t*)malloc(sizeof(node_t));
	temp->data = data;
	temp->next=NULL;
	temp->prev=NULL;
	if(list->head == NULL)
	{
		list->head = temp;
        list->tail= temp;
	}
	else
	{
        node_t *current = list->tail;
        current->next = temp;
        temp->prev = current;
        list->tail = temp;
	}
    list->size = list->size + 1;

}

void insert_after(list_t* list, int data, int prev) // TODO: inserts data after the node with data “prev”. Do not insert or do anything if prev doesn't exist
{
    node_t *temp = (node_t*)malloc(sizeof(node_t));
    temp->data = data;
	temp->next = NULL;
	temp->prev =NULL;

    if(!(is_empty(list)))
    {
        node_t *p = search(list, prev);
        if(p!=NULL)
        {
            node_t *next = p->next;
            if(next == NULL)
            {
                insert_back(list,data);
            }
            else
            {
                p->next =temp;
                temp->prev= p;
                next->prev=temp;
                temp->next=next;
                list->size++;
            }
        }
    }
}

void delete_front(list_t* list) // TODO: delete the start node from the linked list.
{
    if(!(is_empty(list))){
        node_t *current = list->head;
        list->head =current->next;
        if(list->head!=NULL){
            list->head->prev = NULL;
        }
        free(current);
        list->size = list->size -1;
        if(list->head == NULL)
        {
            list->tail =NULL;
        }
    }
}

void delete_back(list_t* list) // TODO: delete the end node from the linked list.
{
    if(!(is_empty(list)))
    {
        node_t *x = list->tail;
        node_t *y = x->prev;
        if(y!=NULL)
        {
            y->next = NULL;
        }
        list->tail = y;
        free(x);
        list->size = list->size -1;
        if(list->tail == NULL)
        {
            list->head =NULL;
        }
    }
}

void delete_node(list_t* list, int data) // TODO: delete the node with “data” from the linked list.
{
   if(!(is_empty(list)))
   {
        node_t *temp = search(list,data);
        node_t *prev = temp->prev;
        node_t *current = temp->next;
        if(prev == NULL)
        {
            delete_front(list);
        }
        else if(current == NULL)
        {
            delete_back(list);
        }
        else
        {
            prev->next = current;
            current->prev = prev;
            free(temp);
        }
   }	
}

node_t* search(list_t* list, int data) // TODO: returns the pointer to the node with “data” field. Return NULL if not found.
{
	if(!(is_empty(list)))
    {
        node_t *current = list->head;
        while(current->data!=data && current->next!=NULL)
        {
            current= current->next;
        }
        if(current->data ==data)
        {
            return(current);
        }
        else{
            return(NULL);
        }
    }
    else{
        return(NULL);
    }		
}

int is_empty(list_t* list) // return true or 1 if the list is empty; else returns false or 0
{
	// DO NOT MODIFY!!!
	return list->size == 0;
}

int size(list_t* list) // returns the number of nodes in the linked list.  
{
	// DO NOT MODIFY!!!
	return list->size;
}

void delete_nodes(node_t* head) // helper
{
	// DO NOT MODIFY!!!
	if(head == NULL)
		return;
	delete_nodes(head->next);
	free(head);	
}

void delete_list(list_t* list) // free all the contents of the linked list
{
	// DO NOT MODIFY!!!
	delete_nodes(list->head);
	free(list);
}

void display_list(list_t* list) // print the linked list by separating each item by a space and a new line at the end of the linked list.
{
	// DO NOT MODIFY!!!
	node_t* it = list->head;
	while(it != NULL)
	{
		printf("%d ", it->data);
		it = it->next;
	}
	printf("\n");
}


