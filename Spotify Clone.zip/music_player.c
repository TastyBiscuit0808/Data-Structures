#include "queue.h"
#include "music_player.h"
#include "dll.h"
#include <stdlib.h>
#include <stdio.h>


playlist_t* create_playlist() // return a newly created doubly linked list
{
	// DO NOT MODIFY!!!
	playlist_t* playlist = (playlist_t*) malloc(sizeof(playlist_t));
	playlist->list = create_list();
	playlist->num_songs = 0;										
	playlist->last_song = NULL;							
	return playlist;
}

void delete_playlist(playlist_t* playlist) // delete the playlist
{
	// DO NOT MODIFY!!!
	delete_list(playlist->list);
	free(playlist);
}

music_queue_t* create_music_queue() // return a newly created queue
{
	// DO NOT MODIFY!!!
	return create_queue();
}

void clear_music_queue(music_queue_t* q) // clear the queue q
{	
	// DO NOT MODIFY!!!
	delete_queue(q);
}

void add_song(playlist_t* playlist, int song_id, int where) // TODO: add a song id to the end of the playlist
{
	if(where == -1)
	{
		insert_front(playlist->list,song_id);
		playlist->num_songs = playlist->num_songs + 1;
	}
	if(where == -2)
	{
		insert_back(playlist->list,song_id);
		playlist->num_songs = playlist->num_songs + 1;
	}
	else if(where>=0)
	{
		insert_after(playlist->list,song_id,where);
		playlist->num_songs = playlist->num_songs + 1;
	}
}

void delete_song(playlist_t* playlist, int song_id) // TODO: remove song id from the playlist
{
	delete_node(playlist->list,song_id);
	playlist->num_songs = playlist->num_songs -1;
}

song_t* search_song(playlist_t* playlist, int song_id) // TODO: return a pointer to the node where the song id is present in the playlist
{
	// return(search(playlist->list,song_id));
	song_t* ss=search(playlist->list,song_id);
	return ss;
}

void search_and_play(playlist_t* playlist, int song_id) // TODO: play the song with given song_id from the list(no need to bother about the queue. Call to this function should always play the given song and further calls to play_next and play_previous)
{
	int found = 0;
	song_t* aux = playlist->list->head;
	while(aux!=NULL)
	{
		if(aux->data==song_id)
		{
			play_song(aux->data);
			found=1;
			break;
		}
		aux=aux->next;
	}
}

void play_next(playlist_t* playlist, music_queue_t* q) // TODO: play the next song in the linked list if the queue is empty. If the queue if not empty, play from the queue
{
	if(is_empty(playlist->list))
	{
		return;
	} 
	else if(empty(q))
	{
		if(playlist->last_song->next && playlist->last_song)
		{
			search_and_play(playlist,playlist->last_song->next->data);
		} 
		else 
		{
			search_and_play(playlist,playlist->list->head->data);
		} 		
	} 
	else 
	{
		play_from_queue(q);
	}
}

void play_previous(playlist_t* playlist) // TODO: play the previous song from the linked list
{
	if(is_empty(playlist->list))
	{
		printf("\n");
	} 
	else 
	{
		if(playlist->last_song == NULL || playlist->last_song->prev == NULL)
		{
			search_and_play(playlist, playlist->list->tail->data);
		} 
		else 
		{
			search_and_play(playlist, playlist->last_song->prev->data);
		}
	}
	
}
void play_from_queue(music_queue_t* q) // TODO: play a song from the queue
{
	int x = q->front->data;
	dequeue(q);
	play_song(dequeue(q));
}

void insert_to_queue(music_queue_t* q, int song_id) // TODO: insert a song id to the queue
{
	enqueue(q,song_id);
}

void reverse(playlist_t* playlist) // TODO: reverse the order of the songs in the given playlist. (Swap the nodes, not data)
{
	song_t *temp = NULL;
    song_t *cur = playlist->list->head;
    while(cur!=NULL)
    {
        temp = cur->prev;										   
        cur->prev = cur->next;										
        cur->next = temp;
        cur = cur->prev;
    }
    if(temp!=NULL)
    {
        playlist->list->head = temp->prev;
    }
}

void k_swap(playlist_t* playlist, int k) // TODO: swap the node at position i with node at position i+k upto the point where i+k is less than the size of the linked list
{
	if(playlist->list->head == NULL)
	{
		printf("\n");
	}
	else if(playlist->list->head == playlist->list->tail)
	{
		printf("\n");
	}
	else if(k == 1)
	{
		song_t *temp = playlist->list->head;
		temp->next->prev = NULL;
		playlist->list->head = temp->next;
		temp->prev = playlist->list->tail;
		playlist->list->tail->next = temp;
		temp->next = NULL;
	}
	else
	{
		for(int i = 0;(k + i)<playlist->list->size;i++)
		{
			int x1 = 0;
			int x2 = 0;
			song_t *temp1 = playlist->list->head;
			song_t *temp2 = playlist->list->head;
			while(x1!=i)
			{
				temp1 = temp1->next;
				x1++;
			}
			while(x2!=(i+k))
			{
				temp2 = temp2->next;
				x2++;
			}
			song_t *temp1p = temp1->prev;
			song_t *temp1n = temp1->next;
			if(temp1 == playlist->list->head)
			{
				playlist->list->head = temp2;
			}
			if(temp2 == playlist->list->tail)
			{
				playlist->list->tail = temp1;
			}
			temp1->prev = temp2->prev;
			temp1->next = temp2->next;
			temp2->prev = temp1p;
			temp2->next = temp1n;
			if(temp2->next!=NULL)
			{
				temp2->next->prev = temp2;
			}
			if(temp1->next!=NULL)
			{
				temp1->next->prev = temp1;
			}
			
			if(temp1->prev!=NULL)
			{
				temp1->prev->next = temp1;
			}
			if(temp2->prev!=NULL)
			{
				temp2->prev->next = temp2;
			}

		}
	}
}

void shuffle(playlist_t* playlist, int k) // TODO: perform k_swap and reverse
{
	if(playlist->list->head!=NULL)
	{
		k_swap(playlist,k);
		reverse(playlist);
	}
}

song_t* debug(playlist_t* playlist) // TODO: if the given linked list has a cycle, return the start of the cycle, else return null. Check cycles only in forward direction i.e with the next pointer. No need to check for cycles in the backward pointer.
{
	song_t *slow = playlist->list->head;
    song_t *fast = playlist->list->head;
    while(fast!=NULL && slow!=NULL)
    {
        slow = slow->next;
        fast = fast->next->next;									
        if(slow == fast)
        {
            return slow;
			// return NULL;
        }
    }
    return NULL;
}

void display_playlist(playlist_t* p) // Displays the playlist
{
	// DO NOT MODIFY!!!
	display_list(p->list);
}

void play_song(int song_id)
{
	// DO NOT MODIFY!!!
	printf("Playing: %d\n", song_id);
}

